import Queue from "../Components/Queue";
const BeverageQueue = () => { 
    return <Queue/>
};
export default BeverageQueue;
