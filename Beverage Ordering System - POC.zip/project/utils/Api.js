const data = "https://68c948cdceef5a150f643206.mockapi.io/data/MenuData";
export default data;