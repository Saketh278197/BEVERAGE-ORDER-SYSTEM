import { Link } from "react-router";
import "../style/Navbar.css";
import { useLocation } from "react-router";
const Navbar = () => {
  const location = useLocation();
  return (
    <div className="navbar">
      <h2 className="logo">🍹BeverageApp</h2>
      <ul>
        <li>
          <Link to="/">Home</Link>
        </li>
        <li>
          <Link to="/queue">Queue</Link>
        </li>
        {location.pathname === "/queue" && (
          <li>
            <Link to="/queue/collected">History</Link>
          </li>
        )}
      </ul>
    </div>
  );
};
export default Navbar;
