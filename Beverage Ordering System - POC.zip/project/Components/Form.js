import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { addToInQueue } from "../utils/ReduxStore/BevSlice";
// import data from "../utils/Data";
import "../style/form.css";
import useBeverageMenu from "../Custom Hooks/UseBeverageMenu";

const Form = () => {
  const data = useBeverageMenu();
  console.log(data);
  const [name, setName] = useState("");
  const [beverage, setBeverage] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [detailsMissMatch, setDetailsMissMatch] = useState(false);
  const dispatch = useDispatch();
  const submit = (e) => {
    e.preventDefault();
    if (!name || !beverage) {
      setShowModal(false);
      setDetailsMissMatch(true);
      setTimeout(() => {
        setDetailsMissMatch(false);
      }, 3000);
      return;
    }
    dispatch(addToInQueue({ id: Date.now(), name: name, Drink: beverage }));
    setShowModal(true);
    console.log("Order submitted:", name, beverage);
    setName("");
    setBeverage("");
    setTimeout(() => {
      setShowModal(false);
    }, 3000);
  };

  return (
    <div className="form">
      <h3 className="title">ORDER YOUR BEVERAGE</h3>
      <form onSubmit={submit}>
        <div className="form-container">
          <div className="textbox">
            <label className="label">Name</label>
            <input
              className="text"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <div className="SelectBox">
            <label className="label">Beverage</label>
            <div className="select-wrapper">
              <select
                value={beverage}
                className="select"
                onChange={(e) => setBeverage(e.target.value)}
              >
                <option value=""> - Please Select -</option>
                {data.map((NameOfDrink) => (
                  <option key={NameOfDrink.id} value={NameOfDrink.name}>
                    {NameOfDrink.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <div className="submit">
            <button type="submit">Submit</button>
          </div>
        </div>
      </form>
      {detailsMissMatch && (
        <div className="MissMatch-alert">
          <p>❌ Enter Your Name and Beverage Correctly</p>
        </div>
      )}
      {showModal && (
        <div className="custom-alert">
          <p>✅ Order Submitted Successfully!</p>
        </div>
      )}
    </div>
  );
};
export default Form;
