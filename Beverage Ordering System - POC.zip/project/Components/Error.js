import { useRouteError } from "react-router";

function ErrorPage() {
  const err = useRouteError();
  return (
    <div className="error-page">
      <h2>404 - Page Not Found</h2>
      <p>{err.Status}</p>
    </div>
  );
}

export default ErrorPage;
