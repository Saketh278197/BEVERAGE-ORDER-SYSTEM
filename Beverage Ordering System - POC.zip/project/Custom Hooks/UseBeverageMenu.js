import { useEffect, useState } from "react";
import data from "../utils/Api";
const useBeverageMenu = () => {
  const [menu, setMenu] = useState([]);
  useEffect(() => {
    fetchdata();
  }, []);

  const fetchdata = async () => {
    try {
      const response = await fetch(data);
      if (!response.ok) {
        throw new Error("Check Your Network Connection ");
      }
      const jsondata = await response.json();
      setMenu(jsondata);
    } catch (err) {
      setError(err.message || "Something went wrong");
    }
  };
  return menu;
};
export default useBeverageMenu;
