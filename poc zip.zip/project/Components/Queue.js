import { useDispatch, useSelector } from "react-redux";
import UserDetails from "./UserDetails";
import "../style/Queue.css"
import {
  MoveToBeingMixQueue,
  MoveToReadyQueue,
  MoveToCollected,
} from "../utils/ReduxStore/BevSlice";
const Queue = () => {
  const { InTheQueue, MixingQueue, ReadyQueue } = useSelector(
    (state) => state.Beverage
  );
  const dispatch = useDispatch();
  return (
    <div className="queue">
      <center>
        <h2>BEVERAGE QUEUE</h2>
      </center>

      <div className="QueueContainer">
        <UserDetails
          title={"IN THE QUEUE"}
          order={InTheQueue}
          onClickCard={(o) => dispatch(MoveToBeingMixQueue(o))}
        />
        <UserDetails
          title={"BEING MIXED"}
          order={MixingQueue}
          onClickCard={(o) => dispatch(MoveToReadyQueue(o))}
        />
        <UserDetails 
          title={"READY TO COLLECT"}
          order={ReadyQueue}
          onClickCard={(o) => dispatch(MoveToCollected(o))}
        />
      </div>
    </div>
  );
};
export default Queue;
