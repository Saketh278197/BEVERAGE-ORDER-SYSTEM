import { useEffect, useState } from "react";
import data from "../utils/Data";
import Description from "./Description";
import "../style/beverage_Menu.css";
const Menu = () => {
  const [selectedId, setSelectedId] = useState(null);
  const [Menudata, SetMenuData] = useState([]);
  const [GoodRated, SetGoodRated] = useState(" - OFF");
  const [filteredMenu, setFilteredMenu] = useState([]);
  useEffect(() => {
    SetMenuData(data);
    setFilteredMenu(data); 
  }, []);
  const handleClick = (id) => {
    setSelectedId((prevId) => (prevId === id ? null : id));
  };
  function StarRated() {
    if (GoodRated === " - ON") {
      SetGoodRated(" - OFF");
      setFilteredMenu(Menudata);
    } else {
      SetGoodRated(" - ON");
      const newMenu = Menudata.filter((menu) => menu.starrated === "yes");
      setFilteredMenu(newMenu);
    }
  }
  return (
    <>
      <div className="Menu">
        <div >
          <button className="filter" onClick={StarRated}>
            MustTry{GoodRated}
          </button>
          <h1>Beverage Menu</h1>
        </div>

        {filteredMenu.map((item) => (
          <div key={item.id}>
            <div className="MenuItem" onClick={() => handleClick(item.id)}>
              <span>{item.name}</span>
              <span>&#11167;</span>
            </div>
            {selectedId === item.id && <Description description={item} />}
          </div>
        ))}
      </div>
    </>
  );
};

export default Menu;
