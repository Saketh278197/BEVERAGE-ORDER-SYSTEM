import ReactDOM from "react-dom/client";
import FormMenuView from "../View/MenuForm";
import { BrowserRouter, Route, Routes } from "react-router";
import BeverageQueue from "../View/BeverageQueue";
import BevStore from "../utils/ReduxStore/BevStore";
import { Provider } from "react-redux";
import Navbar from "./NavBar";
import "../style/NavBar.css";
import "../style/form.css";
import "../style/Media.css"
function App() {
  return (
    <Provider store={BevStore}>
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route path="/" element={<FormMenuView />} />
          <Route path="/queue" element={<BeverageQueue />} />
        </Routes>
      </BrowserRouter>
    </Provider>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
