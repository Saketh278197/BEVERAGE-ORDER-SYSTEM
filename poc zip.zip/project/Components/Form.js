import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { addToInQueue } from "../utils/ReduxStore/BevSlice";
import data from "../utils/Data";
import "../style/form.css";

const Form = () => {
  const [name, setName] = useState("");
  const [Beverage, setBeverage] = useState("");
  const [showModal, setShowModal] = useState(false);

  const dispatch = useDispatch();
  const submit = (e) => {
    e.preventDefault();
    if (!name || !Beverage) {
      setShowModal(false);
      return;
    }
    dispatch(addToInQueue({ id: Date.now(), name: name, Drink: Beverage }));
    setShowModal(true);
    console.log("Order submitted:", name, Beverage);
    setName("");
    setBeverage("");

    setTimeout(() => {
      setShowModal(false);
    }, 3000);
  };

  return (
    <div className="form">
      <h3 className="title">ORDER YOUR BEVERAGE</h3>
      <form onSubmit={submit}>
        <div className="form-container">
          <div className="textbox">
            <label className="label">Name</label>
            <input
              className="text"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <div className="SelectBox">
            <label className="label">Beverage</label>
            <div className="select-wrapper">
              <select
                value={Beverage}
                className="select"
                onChange={(e) => setBeverage(e.target.value)}
              >
                <option value="">- Please Select -</option>
                {data.map((NameOfDrink) => (
                  <option key={NameOfDrink.id} value={NameOfDrink.name}>
                    {NameOfDrink.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <div className="submit">
            <button type="submit">Submit</button>
          </div>
        </div>
      </form>
      {showModal && (
        <div className="custom-alert">
          <p>✅ Order Submitted Successfully!</p>
        </div>
      )}
    </div>
  );
};

export default Form;
