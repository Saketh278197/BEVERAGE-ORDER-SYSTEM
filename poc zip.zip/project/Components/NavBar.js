import { Link } from "react-router";
import "../style/Navbar.css";
const Navbar = () => {
  return (
    <div className="navbar">
      <h2 className="logo">
        🍹BeverageApp
      </h2>
      <ul>
        <li>
          <Link to="/">Home</Link>
        </li>
        <li>
          <Link to="/queue">Queue</Link>
        </li>
      </ul>
    </div>
  );
};
export default Navbar;
