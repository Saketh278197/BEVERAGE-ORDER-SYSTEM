import { createSlice } from "@reduxjs/toolkit";

export const beverageslice = createSlice({
  name: "Beverage",
  initialState: {
    InTheQueue: [],
    MixingQueue: [],
    ReadyQueue: [],
    isCollected : false,
  },
  reducers: {
    addToInQueue: (state, action) => {
      state.InTheQueue.push(action.payload);
      console.log(action.payload);
    },
    //first remove orderthat order in the InTheQueue and add to the MixingQueue
    MoveToBeingMixQueue: (state, action) => {
      state.InTheQueue = state.InTheQueue.filter(
        (o) => o.id !== action.payload.id
      );
      state.MixingQueue.push(action.payload);
      // const order = state.InTheQueue.shift()
      // state.MixingQueue.push(order);
    },
    //first remove from mixing queue and add to ready queue
    MoveToReadyQueue: (state, action) => {
      // const order = state.MixingQueue.shift()
      // state.ReadyQueue.push(order);
      state.MixingQueue = state.MixingQueue.filter(
        (o) => o.id !== action.payload.id
      );
      state.ReadyQueue.push(action.payload);
    },
    //when user click on the Ready to collect means the user is collected that item so remove from ready to collect
    MoveToCollected: (state, action) => {
      state.ReadyQueue = state.ReadyQueue.filter(
        (o) => o.id !== action.payload.id
      );

      // state.ReadyQueue.shift();
    },
  },
});
export default beverageslice.reducer;
export const {
  addToInQueue,
  MoveToBeingMixQueue,
  MoveToReadyQueue,
  MoveToCollected,
} = beverageslice.actions;
