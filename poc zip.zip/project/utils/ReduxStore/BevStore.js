import { configureStore } from "@reduxjs/toolkit";
import beveragesReducer from "../ReduxStore/BevSlice";

const BevStore = configureStore({
  reducer: {
    Beverage: beveragesReducer,
  },
});

export default BevStore;
